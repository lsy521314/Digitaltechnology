@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Node.js。请先安装 Node.js 20 LTS 或更高版本。
  echo 安装后重新双击本文件。
  pause
  exit /b 1
)
echo 正在启动“智御网络”本地预览服务……
echo 浏览器访问地址：http://127.0.0.1:4173
node server.mjs
pause
