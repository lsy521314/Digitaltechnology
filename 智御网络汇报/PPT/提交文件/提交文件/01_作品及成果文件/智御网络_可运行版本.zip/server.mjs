import { createServer } from 'node:http'
import { readFile, stat } from 'node:fs/promises'
import { extname, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(fileURLToPath(new URL('./dist/', import.meta.url)))
const port = Number(process.env.PORT || 4173)

const types = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
}

function safePath(pathname) {
  const decoded = decodeURIComponent(pathname).replace(/^\/+/, '')
  const target = resolve(root, decoded || 'index.html')
  return target === root || target.startsWith(`${root}${sep}`) ? target : null
}

async function existingFile(pathname) {
  const target = safePath(pathname)
  if (!target) return null
  try {
    const info = await stat(target)
    return info.isFile() ? target : null
  } catch {
    return null
  }
}

createServer(async (request, response) => {
  try {
    const url = new URL(request.url || '/', 'http://localhost')
    const requested = await existingFile(url.pathname)
    const target = requested || resolve(root, 'index.html')
    const body = await readFile(target)
    response.writeHead(200, {
      'Content-Type': types[extname(target).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': target.endsWith('index.html') ? 'no-cache' : 'public, max-age=3600',
    })
    response.end(body)
  } catch (error) {
    response.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' })
    response.end(`启动失败：${error instanceof Error ? error.message : String(error)}`)
  }
}).listen(port, '127.0.0.1', () => {
  console.log(`智御网络已启动：http://127.0.0.1:${port}`)
  console.log('请在浏览器中打开上述地址；按 Ctrl+C 停止服务。')
})
